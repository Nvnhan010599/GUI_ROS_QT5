from logging import error, setLogRecordFactory
from PyQt5 import uic
from PyQt5 import QtWidgets,QtCore
from PyQt5.QtCore import pyqtSignal, pyqtSlot,qrand
from PyQt5.QtWidgets import QApplication, QComboBox, QTextEdit, QLabel, QGroupBox, QLineEdit, QPushButton, QWidget,\
                            QComboBox, QTableWidget, QTabWidget, QRadioButton
import sys
import math
from PyQt5.sip import setdeleted

import rospy
import rosgraph
from rospy.core import rospywarn
from std_msgs.msg import String
from geometry_msgs.msg import PoseStamped, PointStamped, PoseWithCovarianceStamped
from nav_msgs.msg import Path
from turtlesim.msg import Pose as turtlePos


TOPIC_UART_DATA_FROM_STM = "uart/data_from_STM"				# subcribe topic

TOPIC_UART_DATA_TO_STM = "uart/data_to_STM"					# publish & subcribe topic

TOPIC_GUI_POS_ROBOT = "GUI/pos_robot"						# publish topic

# TOPIC_PLOT_GOAL_POINT = "GUI/rviz_goal_point"				# publish topic

TOPIC_PLOT_GOAL_POINT = "/clicked_point"		     		# publish topic

TOPIC_PLOT_POSE_ROBOT = "GUI/rviz_pos_robot"				# publish topic

# TOPIC_ORB_POS_ROBOT = "ORB/pos_robot" # turtlesim/Pose		# subcribe topic
TOPIC_ORB_POS_ROBOT = "/turtle1/pose"

TOPIC_GET_GOAL_POINT = "/clicked_point"				# subcribe topic 

TOPIC_GET_PATH_TARGET = "/dwa/PathTarget"					# publish & subcribe topic

TOPIC_CMD_WITH_A_STAR_NODE = "GUI/path_create"				# publish & subcribe topic

TOPIC_PLOT_TRAJECTORY_ROBOT = "GUI/trajectory_robot"        # publish topic

FRAME_ID = "/map"

SERIAL_FRAME_BEGIN = "&"
SERIAL_FRAME_END = "@"
SERIAL_BYTE_END = "!"
SERIAL_BEGIN_PATH_X_FRAME = "Ux"
SERIAL_PRE_VALUE_PATH_X = "xx"

SERIAL_BEGIN_PATH_Y_FRAME = "Uy"
SERIAL_PRE_VALUE_PATH_Y = "yy"

SERIAL_BEGIN_ORB_POS_FRAME = "OP"
SERIAL_ORB_POS_X = "oX"
SERIAL_ORB_POS_Y = "oY"
SERIAL_ORB_POS_THETA = "oT"

SERIAL_BEGIN_MODE_SELECTION_FRAME = "DM"
SERIAL_MODE_CHOOSE = "am"
SERIAL_DIR_MAN = "dm"

SERIAL_BEGIN_FROM_STM = "#"

ROBOT_2_WHEELS_DIS = 0.34
ROBOT_RADIUS_WHEEL = 145.0/2.0/1000
ERROR_STANDARD = 0.1

def euler_to_quaternion(roll, pitch, yaw):

	qx = math.sin(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) - math.cos(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
	qy = math.cos(roll/2) * math.sin(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.cos(pitch/2) * math.sin(yaw/2)
	qz = math.cos(roll/2) * math.cos(pitch/2) * math.sin(yaw/2) - math.sin(roll/2) * math.sin(pitch/2) * math.cos(yaw/2)
	qw = math.cos(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)

	return [qx, qy, qz, qw]

def is_number(string):
    try:
        float(string)
        return True
    except ValueError:
        return False


class My_UI(QWidget):
	signal_orb_pos = pyqtSignal()
	signal_uart_to_STM = pyqtSignal()
	signal_uart_from_STM = pyqtSignal()
	signal_2D_Goal_Nav = pyqtSignal()
	signal_cmd_a_star_node = pyqtSignal()
	signal_path_target = pyqtSignal()

	def __init__(self):
		super(My_UI, self).__init__()
		uic.loadUi("Mybot_GUI.ui",self)

		# TAB
		self.main_tab = self.findChild(QTabWidget,"main_tab")
		self.main_tab.currentChanged.connect(self.main_tab_changeTab)

		# LABEL 
		self.check_goal_lbl = self.findChild(QLabel,"check_goal_lbl")
		self.test_label = self.findChild(QLabel,"test_label")

		# RADIO BUTTON
		self.rfRemote_radio_btn = self.findChild(QRadioButton,"rfRemote_radio_btn")
		self.rfRemote_radio_btn.toggled.connect(lambda: self.mode_selection_slot("rf"))
		self.teleop_radio_btn = self.findChild(QRadioButton,"teleop_radio_btn")
		self.teleop_radio_btn.toggled.connect(lambda: self.mode_selection_slot("teleop"))
		self.auto_radio_btn = self.findChild(QRadioButton,"auto_radio_btn")
		self.auto_radio_btn.toggled.connect(lambda: self.mode_selection_slot("auto"))

		self.a_star_radio_btn = self.findChild(QRadioButton,"a_star_radio_btn")
		self.a_star_radio_btn.toggled.connect(lambda: self.gen_path_selection_slot("a"))

		self.user_radio_btn = self.findChild(QRadioButton,"user_radio_btn")
		self.user_radio_btn.toggled.connect(lambda: self.gen_path_selection_slot("user"))

		# PUSH BUTTON
		self.run_btn = self.findChild(QPushButton,"run_btn")
		self.stop_btn = self.findChild(QPushButton,"stop_btn")
		self.send_path_btn = self.findChild(QPushButton,"send_path_btn")
		self.plot_path_btn = self.findChild(QPushButton,"plot_path_btn")
		self.add_point_btn = self.findChild(QPushButton,"add_point_btn")
		self.remove_point_btn = self.findChild(QPushButton,"remove_point_btn")
		self.remove_all_point_btn = self.findChild(QPushButton,"remove_all_point_btn")
		self.send_goal_btn = self.findChild(QPushButton, "send_goal_btn")
		self.begin_collect_btn = self.findChild(QPushButton,"begin_collect_btn")
		self.stop_collect_btn = self.findChild(QPushButton,"stop_collect_btn")
		self.remove_collect_btn = self.findChild(QPushButton,"remove_collect_btn")
		self.plot_trajectory_btn = self.findChild(QPushButton,"plot_trajectory_btn")
		self.prepare_btn = self.findChild(QPushButton,"prepare_btn")

		# TABLE
		self.path_table = self.findChild(QTableWidget,"path_table")
		self.table_remove_all_row(self.path_table)
		for i in range(10):
			data = [i,i]
			self.table_add_row(self.path_table,data)
		
		self.pos_robot_table = self.findChild(QTableWidget,"pos_robot_table")
		self.table_remove_all_row(self.pos_robot_table)

		data = [0,0,0,0]
		self.table_add_row(self.pos_robot_table,data)

		self.evaluate_table = self.findChild(QTableWidget,"evaluate_table")

		# LINE EDIT 
		self.current_mode_line_edit = self.findChild(QLineEdit,"current_mode_line_edit")

		self.goal_x_line_edit = self.findChild(QLineEdit,"goal_x_line_edit")
		self.goal_y_line_edit = self.findChild(QLineEdit,"goal_y_line_edit")

		self.pos_x_line_edit = self.findChild(QLineEdit,"pos_x_line_edit")
		self.pos_y_line_edit = self.findChild(QLineEdit,"pos_y_line_edit")
		self.pos_theta_line_edit = self.findChild(QLineEdit,"pos_theta_line_edit")
		self.pos_vel_line_edit = self.findChild(QLineEdit,"pos_vel_line_edit")

		self.posOrb_x_line_edit = self.findChild(QLineEdit,"posOrb_x_line_edit")
		self.posOrb_y_line_edit = self.findChild(QLineEdit,"posOrb_y_line_edit")
		self.posOrb_theta_line_edit = self.findChild(QLineEdit,"posOrb_theta_line_edit")		

		self.dwa_v_max_line_edit = self.findChild(QLineEdit,"dwa_v_max_line_edit")
		self.dwa_omega_max_line_edit = self.findChild(QLineEdit,"dwa_omega_max_line_edit")
		self.dwa_al_max_line_edit = self.findChild(QLineEdit,"dwa_al_max_line_edit")
		self.dwa_gr_max_line_edit = self.findChild(QLineEdit,"dwa_gr_max_line_edit")



		# TEXT EDIT

		self.receive_text = self.findChild(QTextEdit,"receive_text")
		self.send_text = self.findChild(QTextEdit,"send_text")

		# MAKE SIGNAL & SLOT QT #

		self.run_btn.clicked.connect(self.slot_run_btn_click)
		self.stop_btn.clicked.connect(self.slot_stop_btn_click)
		self.send_path_btn.clicked.connect(self.slot_send_path_btn_click)
		self.plot_path_btn.clicked.connect(self.slot_plot_path_btn)
		self.add_point_btn.clicked.connect(self.slot_add_point_btn)
		self.remove_point_btn.clicked.connect(self.slot_remove_point_btn)
		self.remove_all_point_btn.clicked.connect(self.slot_remove_all_point_btn)
		self.send_goal_btn.clicked.connect(self.slot_send_goal_btn)
		self.begin_collect_btn.clicked.connect(self.slot_begin_collect_btn)
		self.stop_collect_btn.clicked.connect(self.slot_stop_collect_btn)
		self.remove_collect_btn.clicked.connect(self.slot_remove_collect_btn)
		self.plot_trajectory_btn.clicked.connect(self.slot_plot_trajectory_btn)
		self.prepare_btn.clicked.connect(self.slot_prepare_btn)
		#--------------------------#


		# INIT PRIVATE VARIABLE #
		
		self.mode_sel = 1
		self.gen_path_sel = 1
		self.mode = 0
		self.flag_collect = 0
		self.target = [math.inf,math.inf]
		self.error_stand = ERROR_STANDARD

		self.begin_collect_btn.setStyleSheet("background-color: gray")
		self.stop_collect_btn.setStyleSheet("background-color: red;color: yellow")
		#--------------------------#

	def table_remove_all_row(self,table):
		while(table.rowCount() > 0):
			table.removeRow(table.rowCount()-1)

	def table_add_row(self,table,data):
		dimension_data = len(data) # 1D array
		rowPosition = table.rowCount()
		table.insertRow(rowPosition)
		for i in range(dimension_data):
			data_text = "{:.2f}".format(data[i])
			table.setItem(rowPosition , i, QtWidgets.QTableWidgetItem(data_text))	

	def table_get_last_item(self,table):
		n_point = table.rowCount() - 1
		if(n_point == -1):
			return [math.inf,math.inf]

		data_table = table.model()
		id_x = data_table.index(n_point,0)
		id_y = data_table.index(n_point,1)
		x = float(data_table.data(id_x))
		y = float(data_table.data(id_y))		
		return [x,y]

	def table_get_index_item(self,table, index):
		data_table = table.model()
		id_x = data_table.index(index,0)
		id_y = data_table.index(index,1)
		x = float(data_table.data(id_x))
		y = float(data_table.data(id_y))		
		return [x,y]

	def main_tab_changeTab(self):
		currentTab = self.main_tab.currentIndex()
		self.test_label.setText(str(currentTab))

	def mode_selection_slot(self, sel):
		if(sel == "rf"):
			if(self.rfRemote_radio_btn.isChecked()):
				self.mode_sel = 1
			else:
				return
		elif(sel == "teleop"):
			if(self.teleop_radio_btn.isChecked()):
				self.mode_sel = 2
			else:
				return
		elif(sel == "auto"):
			if(self.auto_radio_btn.isChecked()):
				self.mode_sel = 3
			else:
				return

	def gen_path_selection_slot(self,sel):
		if(sel == "a"):
			if(self.a_star_radio_btn.isChecked()):
				self.gen_path_sel = 1
				self.send_path_btn.setEnabled(False)
				self.plot_path_btn.setEnabled(False)
				self.remove_all_point_btn.setEnabled(False)
				self.remove_point_btn.setEnabled(False)
				self.add_point_btn.setEnabled(False)
				# self.table_remove_all_row(self.path_table)
			else:
				return
		elif(sel == "user"):
			if(self.user_radio_btn.isChecked()):
				self.gen_path_sel = 2
				self.send_path_btn.setEnabled(True)
				self.plot_path_btn.setEnabled(True)
				self.remove_all_point_btn.setEnabled(True)
				self.remove_point_btn.setEnabled(True)
				self.add_point_btn.setEnabled(True)
	
	def slot_run_btn_click(self):
		self.run_btn.setEnabled(False)
		cmd = SERIAL_FRAME_BEGIN + SERIAL_BEGIN_MODE_SELECTION_FRAME +SERIAL_BYTE_END+\
			SERIAL_DIR_MAN + str(1) + SERIAL_BYTE_END + SERIAL_MODE_CHOOSE + str(self.mode_sel) + SERIAL_BYTE_END + SERIAL_FRAME_END

		data = cmd
		msg = String()
		msg.data = cmd
		self.ros_pub_serial_STM.publish(msg)

		pass

	def slot_stop_btn_click(self):
		cmd = SERIAL_FRAME_BEGIN + SERIAL_BEGIN_MODE_SELECTION_FRAME +SERIAL_BYTE_END+\
			SERIAL_DIR_MAN + str(0) + SERIAL_BYTE_END + SERIAL_MODE_CHOOSE + str(0) + SERIAL_BYTE_END + SERIAL_FRAME_END

		self.run_btn.setEnabled(True)
		msg = String()
		msg.data = cmd
		self.ros_pub_serial_STM.publish(msg)
		
	def slot_send_path_btn_click(self):
		strx = SERIAL_FRAME_BEGIN + SERIAL_BEGIN_PATH_X_FRAME + SERIAL_BYTE_END
		stry = SERIAL_FRAME_BEGIN + SERIAL_BEGIN_PATH_Y_FRAME + SERIAL_BYTE_END
		# &Ux!xx0!xx1!@
		# &Uy!yy0!yy1!@
		delay_1s = rospy.Rate(1)
		n_point = self.path_table.rowCount()
		data_table = self.path_table.model()
		for i in range(n_point):
			id_x = data_table.index(i,0)
			id_y = data_table.index(i,1)

			x = data_table.data(id_x)
			y = data_table.data(id_y)

			strx = strx + SERIAL_PRE_VALUE_PATH_X +"{:.2f}".format(float(x)) + SERIAL_BYTE_END
			stry = stry + SERIAL_PRE_VALUE_PATH_Y +"{:.2f}".format(float(y)) + SERIAL_BYTE_END

		strx += SERIAL_FRAME_END
		stry += SERIAL_FRAME_END

		msg = String()
		msg.data = strx
		self.ros_pub_serial_STM.publish(msg)


		delay_1s.sleep()

		msg.data = stry
		self.ros_pub_serial_STM.publish(msg)

	def slot_plot_path_btn(self):
		path_back = Path()

		path_back.header.frame_id = FRAME_ID
		path_back.header.stamp = rospy.Time.now()

		n_point = self.path_table.rowCount()
		data_table = self.path_table.model()
		for i in range(n_point):
			
			pose = PoseStamped()
			pose.header.frame_id = FRAME_ID
			pose.header.stamp = rospy.Time.now()

			id_x = data_table.index(i,0)
			id_y = data_table.index(i,1)

			x = data_table.data(id_x)
			y = data_table.data(id_y)

			pose.pose.position.x = float(x)
			pose.pose.position.y = float(y)

			path_back.poses.append(pose)

		self.ros_pub_path_target.publish(path_back)

	def slot_add_point_btn(self):

		data = [0,0]
		self.table_add_row(self.path_table,data)

	def slot_remove_point_btn(self):
		a = self.path_table.selectedIndexes()
		set_row = set()
		for item in a:
			set_row.add(item.row())
		list_row = list(set_row)
		for i in range(len(list_row)):
			delta = list_row[i] - list_row[0]
			self.path_table.removeRow(list_row[0] + delta - i)

	def slot_remove_all_point_btn(self):
		self.table_remove_all_row(self.path_table)
	
	def slot_send_goal_btn(self):
		x = self.goal_x_line_edit.text()
		y = self.goal_y_line_edit.text()
		delay = rospy.Rate(10)
		if(is_number(x) and is_number(y)):


			point = PointStamped()
			point.header.frame_id = FRAME_ID
			point.header.stamp = rospy.rostime.Time.now()

			point.point.x = float(x)
			point.point.y = float(y)
			point.point.z = 0

			self.ros_pub_plot_goal.publish(point)
			delay.sleep()
			msgs = String()	
			msgs.data = "o"
			self.ros_pub_cmd_a_star_node.publish(msgs)

			data = f"<font color= 'green'> getting path </font>"
			self.check_goal_lbl.setText(data)
			self.check_goal_lbl.adjustSize()

		else:
			data = f"<font color= 'red'> invaid input </font>"
			self.check_goal_lbl.setText(data)
			self.check_goal_lbl.adjustSize()

	def slot_begin_collect_btn(self):
		self.flag_collect = 1
		self.begin_collect_btn.setStyleSheet("background-color: green")
		self.stop_collect_btn.setStyleSheet("background-color: gray")
		self.begin_collect_btn.setEnabled(False)

	def slot_stop_collect_btn(self):
		self.flag_collect = 0
		self.begin_collect_btn.setStyleSheet("background-color: gray")
		self.stop_collect_btn.setStyleSheet("background-color: red;color: yellow")

		self.begin_collect_btn.setEnabled(True)

	def slot_remove_collect_btn(self):
		self.table_remove_all_row(self.pos_robot_table)
		
	def slot_plot_trajectory_btn(self):
		path_back = Path()

		path_back.header.frame_id = FRAME_ID
		path_back.header.stamp = rospy.Time.now()

		n_point = self.pos_robot_table.rowCount()
		data_table = self.pos_robot_table.model()
		for i in range(n_point):
			
			pose = PoseStamped()
			pose.header.frame_id = FRAME_ID
			pose.header.stamp = rospy.Time.now()

			id_x = data_table.index(i,0)
			id_y = data_table.index(i,1)

			x = data_table.data(id_x)
			y = data_table.data(id_y)

			pose.pose.position.x = float(x)
			pose.pose.position.y = float(y)
			
			path_back.poses.append(pose)

		self.ros_pub_trajectoryRobot.publish(path_back) 

	def slot_prepare_btn(self):
		self.table_remove_all_row(self.evaluate_table)
		n_ref = self.path_table.rowCount()
		n_pos = self.pos_robot_table.rowCount()
		index_pos_begin = 0
		index_pos_min = 0
		if(n_ref < 1 or n_pos < 1 ):
			return
		else:
			for index_path in range(n_ref):
				[xd,yd] = self.table_get_index_item(self.path_table,index_path)
				min_dist = math.inf
				for index_pos in range(index_pos_begin,n_pos):
					[x,y] = self.table_get_index_item(self.pos_robot_table,index_pos)
					dist = math.hypot(xd-x,yd-y)
					if(min_dist > dist):
						min_dist = dist
						index_pos_min = index_pos
				[x,y] = self.table_get_index_item(self.pos_robot_table,index_pos_min)
				index_pos_begin = index_pos_min 
				data = [xd,yd,x,y,min_dist]
				self.table_add_row(self.evaluate_table,data)

	def ros_init(self):
		rospy.init_node("GUI_Monitor",anonymous=True)

		# publisher 
		self.ros_pub_serial_STM = rospy.Publisher(TOPIC_UART_DATA_TO_STM,String, queue_size=1) # serial to stm
		self.ros_pub_posRobot = rospy.Publisher(TOPIC_GUI_POS_ROBOT,turtlePos, queue_size=1)   # posRobot from STM, handled
		self.ros_pub_plot_goal = rospy.Publisher(TOPIC_PLOT_GOAL_POINT, PointStamped, queue_size=1) # goal want to go
		self.ros_pub_path_target = rospy.Publisher(TOPIC_GET_PATH_TARGET,Path, queue_size=1) # (?)
		self.ros_pub_posRobot_rviz = rospy.Publisher(TOPIC_PLOT_POSE_ROBOT, PoseStamped, queue_size=1)
		self.ros_pub_cmd_a_star_node = rospy.Publisher(TOPIC_CMD_WITH_A_STAR_NODE, String, queue_size=1)
		self.ros_pub_trajectoryRobot = rospy.Publisher(TOPIC_PLOT_TRAJECTORY_ROBOT, Path, queue_size=1)

		# subcriber
		ros_sub_orb_pos = rospy.Subscriber(TOPIC_ORB_POS_ROBOT, turtlePos, self.ros_orb_pos_callback,	queue_size=1)
		ros_sub_uart_to_STM = rospy.Subscriber(TOPIC_UART_DATA_TO_STM, String, self.ros_uart_to_STM_callback, queue_size=1)
		ros_sub_uart_from_STM = rospy.Subscriber(TOPIC_UART_DATA_FROM_STM, String, self.ros_uart_from_STM_callback, queue_size=1)
		ros_sub_2D_Goal_Nav = rospy.Subscriber(TOPIC_GET_GOAL_POINT, PointStamped, self.ros_2D_Goal_Nav_callback, queue_size=1)
		ros_sub_cmd_a_star_node = rospy.Subscriber(TOPIC_CMD_WITH_A_STAR_NODE, String, self.ros_cmd_a_star_node, queue_size=1)
		ros_sub_path_target = rospy.Subscriber(TOPIC_GET_PATH_TARGET, Path, self.ros_path_target, queue_size=1)

		# ROS signal 
		self.signal_orb_pos.connect(self.slotRos_orb_pos)
		self.signal_uart_to_STM.connect(self.slotRos_uart_to_STM)
		self.signal_uart_from_STM.connect(self.slotRos_uart_from_STM)
		self.signal_2D_Goal_Nav.connect(self.slotRos_2D_Goal_Nav)
		self.signal_cmd_a_star_node.connect(self.slotRos_cmd_a_star_node)
		self.signal_path_target.connect(self.slotRos_path_target)

	def process_get_data_from_uart(self,data_str):
		text = data_str.split(SERIAL_BYTE_END)

		self.pos_x_robot = float(text[3][2:])
		self.pos_y_robot = float(text[4][2:])
		self.pos_theta_robot = float(text[5][2:])
		self.v_left = float(text[1][2:])
		self.v_right = float(text[2][2:])
		self.vel = (self.v_left + self.v_right)/2.0/60.0*ROBOT_RADIUS_WHEEL

		self.mode = int(text[6][2:])

		if(self.mode == 0):
			self.mode_robot = f"<font color= 'red'>stop</font>"
		elif(self.mode == 1):
			self.mode_robot = f"<font color= 'green'>remote</font>"
		elif(self.mode == 2):
			self.mode_robot = f"<font color= 'red'>teleop</font>"
		elif(self.mode == 3):
			self.mode_robot = f"<font color= 'red'>auto</font>"



	def ros_orb_pos_callback(self,data):
		self.orb_pos = data
		self.signal_orb_pos.emit()
		pass

	def ros_uart_to_STM_callback(self,data):
		self.data_uart_to_STM = data
		self.signal_uart_to_STM.emit()
		pass

	def ros_uart_from_STM_callback(self,data):
		
		self.data_uart_from_STM = data.data
		index = self.data_uart_from_STM.find('#')
		self.data_uart_from_STM = self.data_uart_from_STM[index:]

		if(len(self.data_uart_from_STM) < 4):
			return
		if(self.data_uart_from_STM[0] != SERIAL_BEGIN_FROM_STM or self.data_uart_from_STM[-1] != SERIAL_FRAME_END):
			return
		self.process_get_data_from_uart(self.data_uart_from_STM)
		self.signal_uart_from_STM.emit()

	def ros_2D_Goal_Nav_callback(self,data):
		self.data_2D_Goal_Nav = data
		self.signal_2D_Goal_Nav.emit()
		pass

	def ros_cmd_a_star_node(self, data):
		self.data_cmd_a_star_node = data
		self.signal_cmd_a_star_node.emit()

	def ros_path_target(self,data):
		self.data_path_target = data
		self.signal_path_target.emit()

	@pyqtSlot()
	def slotRos_orb_pos(self):
		x = "{:.2f}".format(self.orb_pos.x)
		y = "{:.2f}".format(self.orb_pos.y)
		theta = "{:.3f}".format(self.orb_pos.theta)

		self.posOrb_x_line_edit.setText(x)
		self.posOrb_y_line_edit.setText(y)
		self.posOrb_theta_line_edit.setText(theta)

		data = SERIAL_FRAME_BEGIN + SERIAL_BEGIN_ORB_POS_FRAME + SERIAL_BYTE_END + SERIAL_ORB_POS_X + x + SERIAL_BYTE_END +\
				SERIAL_ORB_POS_Y + y + SERIAL_BYTE_END + SERIAL_ORB_POS_THETA + theta + SERIAL_BYTE_END + SERIAL_FRAME_END
		msg = String()
		msg.data = data
		self.ros_pub_serial_STM.publish(msg)
		pass

	@pyqtSlot()
	def slotRos_uart_to_STM(self):
		self.send_text.setText(self.data_uart_to_STM.data)
	
	@pyqtSlot()
	def slotRos_uart_from_STM(self):
		self.receive_text.setText(self.data_uart_from_STM)

		self.pos_x_line_edit.setText(str(self.pos_x_robot))
		self.pos_y_line_edit.setText(str(self.pos_y_robot))
		self.pos_theta_line_edit.setText(str(self.pos_theta_robot))
		self.pos_vel_line_edit.setText(str(self.vel))
		if(self.mode == 0):
			self.current_mode_line_edit.setStyleSheet("color: red;")
			self.current_mode_line_edit.setText("stop")
		elif(self.mode == 1):
			self.current_mode_line_edit.setStyleSheet("color: blue;")
			self.current_mode_line_edit.setText("remote")
		elif(self.mode == 2):
			self.current_mode_line_edit.setStyleSheet("color: yellow;")
			self.current_mode_line_edit.setText("teleop")
		elif(self.mode == 3):
			self.current_mode_line_edit.setStyleSheet("color: green;")
			self.current_mode_line_edit.setText("auto")

		pos = turtlePos()

		pos.x = self.pos_x_robot
		pos.y = self.pos_y_robot

		self.ros_pub_posRobot.publish(pos)

		pose_stamped = PoseStamped()

		pose_stamped.header.frame_id = FRAME_ID
		pose_stamped.header.stamp = rospy.Time.now()
		pose_stamped.pose.position.x = self.pos_x_robot
		pose_stamped.pose.position.y = self.pos_y_robot

		quaternion = euler_to_quaternion(0,0, self.pos_theta_robot)

		pose_stamped.pose.orientation.x = quaternion[0]
		pose_stamped.pose.orientation.y = quaternion[1]
		pose_stamped.pose.orientation.z = quaternion[2]
		pose_stamped.pose.orientation.w = quaternion[3]

		self.ros_pub_posRobot_rviz.publish(pose_stamped)

		# Check condition of distance between pos and target

		self.target = self.table_get_last_item(self.path_table)
		x_t = self.target[0]
		y_t = self.target[1]
		

		dist = math.hypot(self.pos_x_robot-x_t,self.pos_y_robot-y_t)
		
		if(self.mode == 3 and dist <= self.error_stand):
			self.flag_collect = 0
		print(f"{self.flag_collect} ,x_t: {x_t}, y_t: {y_t}, dist : {dist}")
		if(self.flag_collect == 1):
			data = [self.pos_x_robot,self.pos_y_robot]
			self.table_add_row(self.pos_robot_table,data)

	@pyqtSlot()
	def slotRos_2D_Goal_Nav(self):
		x = "{:.2f}".format(self.data_2D_Goal_Nav.point.x)
		y = "{:.2f}".format(self.data_2D_Goal_Nav.point.y)
		self.goal_x_line_edit.setText(x)
		self.goal_y_line_edit.setText(y)
		pass

	@pyqtSlot()
	def slotRos_cmd_a_star_node(self):
		data = self.data_cmd_a_star_node.data
		if(data == 'y'):
			self.check_goal_lbl.setText(f"<font color= 'green'> Done </font>")
		elif(data == 'n'):
			self.check_goal_lbl.setText(f"<font color= 'red'> Invalid input </font>")

	@pyqtSlot()
	def slotRos_path_target(self):
		path = self.data_path_target
		n_row = len(path.poses)
		
		self.table_remove_all_row(self.path_table)

		for i in range(n_row):
			x = path.poses[i].pose.position.x
			y = path.poses[i].pose.position.y

			data_path = [x,y]				
			self.table_add_row(self.path_table,data_path)
		pass
		



app = QApplication(sys.argv)

mybot_gui = My_UI()
mybot_gui.ros_init()
mybot_gui.show()
app.exec_()
